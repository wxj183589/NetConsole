from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
import re

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from netconsole.core.i18n import I18n
from netconsole.repositories.ac_repository import AcRepository
from netconsole.services.trackside_ap_business import normalize_vlan_text, parse_vlan_set
from netconsole.ui.render.table_render_engine import apply_table_style, set_table_column_fields
from netconsole.ui.table.table_autosize_engine import apply_worksheet_autofit


TRACKSIDE_PLAN_COLUMNS = (
    ("ac.trackside_plan.station_name", "station_name"),
    ("ac.trackside_plan.ap_count", "ap_count"),
    ("ac.trackside_plan.ap_start_address", "ap_start_address"),
    ("ac.trackside_plan.mask", "mask_length"),
    ("ac.trackside_plan.ap_gateway", "ap_gateway"),
    ("ac.trackside_plan.ap_management_vlan", "ap_management_vlans"),
)
TRACKSIDE_PLAN_HEADERS = ["车站名称", "AP数量", "AP起始地址", "掩码", "AP网关", "AP管理VLAN"]
TRACKSIDE_PLAN_MODES = ("single_vlan", "multi_vlan")


class TracksideApPlanPage(QWidget):
    plan_saved = Signal()

    def __init__(self, repository: AcRepository, i18n: I18n, site_name: str) -> None:
        super().__init__()
        self.repository = repository
        self.i18n = i18n
        self.site_name = site_name
        self.active_mode_combo = QComboBox()
        self.uniform_vlan_input = QLineEdit()
        self.apply_uniform_button = QPushButton()
        self.mode_tabs = QTabWidget()
        self.tables = {mode: QTableWidget() for mode in TRACKSIDE_PLAN_MODES}
        self.add_button = QPushButton()
        self.delete_button = QPushButton()
        self.save_button = QPushButton()
        self.import_button = QPushButton()
        self.export_button = QPushButton()
        self.template_button = QPushButton()
        self.refresh_button = QPushButton()
        self._build_ui()
        self.retranslate()
        self.refresh()

    def _build_ui(self) -> None:
        top = QHBoxLayout()
        top.addWidget(self.active_mode_combo)
        top.addWidget(self.uniform_vlan_input)
        top.addWidget(self.apply_uniform_button)
        for button in (self.add_button, self.delete_button, self.save_button, self.import_button, self.export_button, self.template_button, self.refresh_button):
            top.addWidget(button)
        top.addStretch(1)

        for mode, table in self.tables.items():
            table.setColumnCount(len(TRACKSIDE_PLAN_COLUMNS))
            set_table_column_fields(table, [field for _key, field in TRACKSIDE_PLAN_COLUMNS])
            table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
            table.horizontalHeader().setStretchLastSection(True)
            apply_table_style(table)
            self.mode_tabs.addTab(table, "")

        layout = QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self.mode_tabs, 1)

        self.active_mode_combo.currentIndexChanged.connect(self.save_active_mode)
        self.apply_uniform_button.clicked.connect(self.apply_uniform_vlan)
        self.add_button.clicked.connect(self.add_row)
        self.delete_button.clicked.connect(self.delete_selected)
        self.save_button.clicked.connect(self.save_current_mode)
        self.import_button.clicked.connect(self.import_current_mode)
        self.export_button.clicked.connect(self.export_plan)
        self.template_button.clicked.connect(self.download_template)
        self.refresh_button.clicked.connect(self.refresh)

    def retranslate(self) -> None:
        self.active_mode_combo.blockSignals(True)
        current = self.active_mode_combo.currentData() or self.repository.get_trackside_ap_plan_mode()
        self.active_mode_combo.clear()
        self.active_mode_combo.addItem(self.i18n.t("ac.trackside_plan.single_vlan_mode"), "single_vlan")
        self.active_mode_combo.addItem(self.i18n.t("ac.trackside_plan.multi_vlan_mode"), "multi_vlan")
        index = self.active_mode_combo.findData(current)
        self.active_mode_combo.setCurrentIndex(index if index >= 0 else 0)
        self.active_mode_combo.blockSignals(False)
        self.uniform_vlan_input.setPlaceholderText(self.i18n.t("ac.trackside_plan.uniform_vlan"))
        self.apply_uniform_button.setText(self.i18n.t("ac.trackside_plan.apply_to_all"))
        self.add_button.setText(self.i18n.t("ac.trackside_plan.add_row"))
        self.delete_button.setText(self.i18n.t("ac.trackside_plan.delete_selected"))
        self.save_button.setText(self.i18n.t("ac.trackside_plan.save"))
        self.import_button.setText(self.i18n.t("ac.trackside_plan.import"))
        self.export_button.setText(self.i18n.t("ac.trackside_plan.export"))
        self.template_button.setText(self.i18n.t("ac.trackside_plan.template"))
        self.refresh_button.setText(self.i18n.t("details.refresh"))
        self.mode_tabs.setTabText(0, self.i18n.t("ac.trackside_plan.single_vlan_mode"))
        self.mode_tabs.setTabText(1, self.i18n.t("ac.trackside_plan.multi_vlan_mode"))
        for table in self.tables.values():
            table.setHorizontalHeaderLabels([self.i18n.t(key) for key, _field in TRACKSIDE_PLAN_COLUMNS])

    def current_mode(self) -> str:
        return TRACKSIDE_PLAN_MODES[self.mode_tabs.currentIndex()]

    def refresh(self) -> None:
        active = self.repository.get_trackside_ap_plan_mode()
        index = self.active_mode_combo.findData(active)
        if index >= 0:
            self.active_mode_combo.setCurrentIndex(index)
        for mode, table in self.tables.items():
            self._set_rows(table, self.repository.list_trackside_ap_plan(mode))

    def add_row(self) -> None:
        table = self.tables[self.current_mode()]
        row = table.rowCount()
        table.insertRow(row)
        for column in range(len(TRACKSIDE_PLAN_COLUMNS)):
            item = QTableWidgetItem("")
            table.setItem(row, column, item)

    def delete_selected(self) -> None:
        table = self.tables[self.current_mode()]
        for row in sorted({index.row() for index in table.selectedIndexes()}, reverse=True):
            table.removeRow(row)

    def save_active_mode(self) -> None:
        mode = str(self.active_mode_combo.currentData() or "single_vlan")
        self.repository.set_trackside_ap_plan_mode(mode)
        self.plan_saved.emit()

    def save_current_mode(self) -> None:
        mode = self.current_mode()
        try:
            rows = self._read_table_rows(self.tables[mode], mode)
        except ValueError as exc:
            QMessageBox.warning(self, self.i18n.t("ac.trackside_plan.validation_failed"), str(exc))
            return
        self.repository.replace_trackside_ap_plan_rows(mode, rows)
        self.repository.set_trackside_ap_plan_mode(str(self.active_mode_combo.currentData() or mode))
        self.refresh()
        self.plan_saved.emit()

    def apply_uniform_vlan(self) -> None:
        try:
            vlan_text = normalize_vlan_text(self.uniform_vlan_input.text())
        except ValueError as exc:
            QMessageBox.warning(self, self.i18n.t("ac.trackside_plan.validation_failed"), str(exc))
            return
        table = self.tables["single_vlan"]
        vlan_column = _field_index("ap_management_vlans")
        for row in range(table.rowCount()):
            table.setItem(row, vlan_column, QTableWidgetItem(vlan_text))

    def import_current_mode(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, self.i18n.t("ac.trackside_plan.import"), "", "Excel/CSV (*.xlsx *.csv)")
        if not path:
            return
        mode = self.current_mode()
        try:
            rows = _dedupe_station_rows(read_trackside_plan_file(Path(path), mode))
            self._validate_rows(rows, mode)
        except ValueError as exc:
            QMessageBox.warning(self, self.i18n.t("ac.trackside_plan.validation_failed"), str(exc))
            return
        self.repository.replace_trackside_ap_plan_rows(mode, rows)
        self.refresh()
        self.plan_saved.emit()

    def export_plan(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.i18n.t("ac.trackside_plan.export"), self._default_export_name(), "Excel (*.xlsx)")
        if not path:
            return
        export_trackside_plan_xlsx(Path(path), {mode: self.repository.list_trackside_ap_plan(mode) for mode in TRACKSIDE_PLAN_MODES})

    def download_template(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, self.i18n.t("ac.trackside_plan.template"), self._default_export_name(template=True), "Excel (*.xlsx)")
        if not path:
            return
        export_trackside_plan_xlsx(Path(path), {mode: [] for mode in TRACKSIDE_PLAN_MODES})

    def _set_rows(self, table: QTableWidget, rows: list[dict[str, object | None]]) -> None:
        table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, (_key, field) in enumerate(TRACKSIDE_PLAN_COLUMNS):
                table.setItem(row_index, column_index, QTableWidgetItem(str(row.get(field) or "")))

    def _read_table_rows(self, table: QTableWidget, mode: str) -> list[dict[str, object | None]]:
        rows = []
        for row_index in range(table.rowCount()):
            row = {field: (table.item(row_index, column_index).text() if table.item(row_index, column_index) else "") for column_index, (_key, field) in enumerate(TRACKSIDE_PLAN_COLUMNS)}
            if not any(str(value or "").strip() for value in row.values()):
                continue
            row["sort_order"] = len(rows)
            rows.append(row)
        self._validate_rows(rows, mode)
        return rows

    def _validate_rows(self, rows: list[dict[str, object | None]], mode: str) -> None:
        seen: set[str] = set()
        for index, row in enumerate(rows, start=2):
            station = str(row.get("station_name") or "").strip()
            if not station:
                raise ValueError(f"第{index}行 车站名称：必填")
            if station.casefold() in seen:
                continue
            seen.add(station.casefold())
            try:
                row["ap_count"] = int(str(row.get("ap_count") or "0").strip())
            except ValueError:
                raise ValueError(f"第{index}行 AP数量：必须是整数") from None
            if int(row["ap_count"]) < 0:
                raise ValueError(f"第{index}行 AP数量：必须是非负整数")
            mask = str(row.get("mask_length") or "").strip()
            if mask:
                try:
                    row["mask_length"] = int(mask)
                except ValueError:
                    raise ValueError(f"第{index}行 掩码：必须是0-32整数") from None
                if int(row["mask_length"]) < 0 or int(row["mask_length"]) > 32:
                    raise ValueError(f"第{index}行 掩码：必须是0-32整数")
            else:
                row["mask_length"] = None
            vlans = parse_vlan_set(row.get("ap_management_vlans"))
            if not vlans:
                raise ValueError(f"第{index}行 AP管理VLAN：必填")
            if mode == "single_vlan" and len(vlans) != 1:
                raise ValueError(f"第{index}行 AP管理VLAN：单VLAN模式只允许一个VLAN")
            row["station_name"] = station
            row["ap_management_vlans"] = ",".join(str(vlan) for vlan in sorted(vlans))
            start = str(row.get("ap_start_address") or "").strip()
            gateway = str(row.get("ap_gateway") or "").strip()
            if start and not _valid_ipv4_or_placeholder(start):
                raise ValueError(f"第{index}行 AP起始地址：格式无效")
            if gateway and not _valid_ipv4(gateway):
                raise ValueError(f"第{index}行 AP网关：必须是IPv4")

    def _default_export_name(self, template: bool = False) -> str:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        suffix = "轨旁AP规划模板" if template else "轨旁AP规划"
        safe_site = re.sub(r'[\\/:*?"<>|]+', "_", str(self.site_name or "").strip()) or "site"
        return f"{safe_site}_{suffix}_{stamp}.xlsx"


def read_trackside_plan_file(path: Path, mode: str) -> list[dict[str, object | None]]:
    if path.suffix.casefold() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return [_row_from_named(row) for row in csv.DictReader(handle)]
    from openpyxl import load_workbook

    workbook = load_workbook(path, data_only=True)
    sheet = workbook[workbook.sheetnames[0]]
    headers = [str(cell.value or "").strip() for cell in sheet[1]]
    rows = []
    for values in sheet.iter_rows(min_row=2, values_only=True):
        raw = {headers[index]: values[index] if index < len(values) else "" for index in range(len(headers))}
        if any(value not in (None, "") for value in raw.values()):
            rows.append(_row_from_named(raw))
    return rows


def export_trackside_plan_xlsx(path: Path, rows_by_mode: dict[str, list[dict[str, object | None]]]) -> None:
    from openpyxl import Workbook

    workbook = Workbook()
    for index, mode in enumerate(TRACKSIDE_PLAN_MODES):
        sheet = workbook.active if index == 0 else workbook.create_sheet()
        sheet.title = "单VLAN模式" if mode == "single_vlan" else "多VLAN模式"
        sheet.append(TRACKSIDE_PLAN_HEADERS)
        for row in rows_by_mode.get(mode, []):
            sheet.append([row.get(field) or "" for _key, field in TRACKSIDE_PLAN_COLUMNS])
        apply_worksheet_autofit(sheet, maximum=50)
    workbook.save(path)


def _row_from_named(row: dict[object, object]) -> dict[str, object | None]:
    mapping = dict(zip(TRACKSIDE_PLAN_HEADERS, [field for _key, field in TRACKSIDE_PLAN_COLUMNS]))
    return {field: row.get(header, "") for header, field in mapping.items()}


def _field_index(field: str) -> int:
    return [item[1] for item in TRACKSIDE_PLAN_COLUMNS].index(field)


def _dedupe_station_rows(rows: list[dict[str, object | None]]) -> list[dict[str, object | None]]:
    by_station: dict[str, dict[str, object | None]] = {}
    order: list[str] = []
    for row in rows:
        station = str(row.get("station_name") or "").strip()
        key = station.casefold()
        if not key:
            order.append(f"__blank_{len(order)}")
            by_station[order[-1]] = row
            continue
        if key not in by_station:
            order.append(key)
        by_station[key] = row
    result = [by_station[key] for key in order if key in by_station]
    for index, row in enumerate(result):
        row["sort_order"] = index
    return result


def _valid_ipv4(value: str) -> bool:
    parts = value.split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(part) <= 255 for part in parts)
    except ValueError:
        return False


def _valid_ipv4_or_placeholder(value: str) -> bool:
    parts = value.split(".")
    if len(parts) != 4:
        return False
    for part in parts:
        if part.upper() == "X":
            continue
        try:
            if int(part) < 0 or int(part) > 255:
                return False
        except ValueError:
            return False
    return True
