from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from netconsole.core import app_logger
from netconsole.core.database import Database
from netconsole.core.paths import PathResolver
from netconsole.models.device import Device
from netconsole.parsers.h3c.device_parser import parse_device
from netconsole.parsers.h3c.ac.fit_ap_optical_parser import parse_fit_ap_optical
from netconsole.parsers.h3c.ac.system_usage_parser import parse_cpu_usage, parse_memory
from netconsole.parsers.h3c.ac.wlan_ap_address_parser import parse_wlan_ap_addresses
from netconsole.parsers.h3c.ac.wlan_ap_parser import parse_wlan_ap_list, parse_wlan_ap_summary
from netconsole.parsers.h3c.ac.wlan_ap_radio_parser import parse_wlan_ap_radios
from netconsole.repositories.ac_repository import AcRepository
from netconsole.repositories.device_fact_repository import DeviceFactRepository
from netconsole.repositories.device_repository import DeviceRepository
from netconsole.services import command_guard
from netconsole.services import netmiko_connection
from netconsole.services.device_web_service import matching_https_port_lines, parse_https_port
from netconsole.services.h3c_collect_service import CommandResult
from netconsole.services.neighbor_matcher import find_neighbor_optical_module, match_ap_from_device_lldp, match_neighbor_device
from netconsole.services.netmiko_connection import build_netmiko_params, choose_connection_target, sanitize_sensitive_text


RESOURCE_COMMANDS = (
    "display wlan ap all",
    "display wlan ap all address",
    "display wlan ap all radio",
    "display cpu-usage",
    "display memory",
    "display version",
    "display device",
    "display device manuinfo",
)

HTTPS_PORT_COMMANDS = (
    "display ip https",
    "display ip https | include port",
)

ENABLE_FIT_AP_CONSOLE_COMMANDS = (
    "screen-length disable",
    "display wlan ap all address",
    "system-view",
    "probe",
    "wlan ap-execute all exec-console enable",
    "return",
    "quit",
)

FIT_AP_OPTICAL_COMMANDS = (
    "screen-length disable",
    "display lldp neighbor-information list",
    "display transceiver diagnosis interface",
    "display transceiver interface",
    "display transceiver manuinfo interface",
)
BATCH_CONCURRENCY = 50


@dataclass(frozen=True)
class AcResourceCollectResult:
    success: bool
    ac_device_uuid: str
    collect_run_uuid: str
    raw_log_path: str
    summary_updated: bool
    fit_ap_resources_updated: int
    https_port: int | None
    https_port_collected: bool
    https_port_persisted: bool
    https_port_error: str | None
    error_message: str | None
    command_results: list[CommandResult] = field(default_factory=list)


@dataclass(frozen=True)
class HttpsPortPersistenceResult:
    persisted_port: int | None
    persisted: bool
    error_message: str | None = None


@dataclass(frozen=True)
class FitApOpticalCollectResult:
    success: bool
    partial_success: bool
    ac_device_uuid: str
    collect_run_uuid: str
    optical_rows_updated: int
    failed_aps: int
    error_message: str | None


def collect_h3c_ac_resources(
    ac_device: Device,
    site_name: str,
    repository: AcRepository | None = None,
    paths: PathResolver | None = None,
) -> AcResourceCollectResult:
    paths = paths or PathResolver()
    repository = repository or AcRepository(Database(paths.site_db_path(site_name)))
    fact_repository = DeviceFactRepository(repository.database)
    ac_device.ensure_device_uuid()
    collect_run_uuid = str(uuid4())
    started_at = _now()
    run_dir = paths.ensure_site_dirs(site_name) / "raw" / "ac" / collect_run_uuid
    run_dir.mkdir(parents=True, exist_ok=True)
    raw_log_file = run_dir / f"{ac_device.device_uuid}.log"
    commands_file = run_dir / f"{ac_device.device_uuid}_commands.jsonl"
    relative_raw_log_path = f"raw/ac/{collect_run_uuid}/{ac_device.device_uuid}.log"

    fact_repository.create_collect_run(
        {
            "collect_run_uuid": collect_run_uuid,
            "collect_type": "ac_resources",
            "status": "running",
            "started_at": started_at,
            "raw_log_dir": f"raw/ac/{collect_run_uuid}",
            "created_at": started_at,
        }
    )
    app_logger.log_info("AC_COLLECT_STARTED", _detail(ac_device, collect_run_uuid))
    app_logger.log_info("REAL_DEVICE_COLLECT_STARTED", _detail(ac_device, collect_run_uuid))
    command_results: list[CommandResult] = []
    if str(ac_device.device_type or "").upper() != "AC" or str(ac_device.device_vendor or "").upper() != "H3C":
        message = "AC resource collection only supports H3C AC devices"
        fact_repository.update_collect_run_status(collect_run_uuid, "failed", error_message=message)
        app_logger.log_error("AC_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        _write_raw_files(raw_log_file, commands_file, ac_device, collect_run_uuid, command_results, fatal_error=message)
        return AcResourceCollectResult(False, str(ac_device.device_uuid), collect_run_uuid, str(raw_log_file), False, 0, None, False, False, None, message, command_results)

    target = choose_connection_target(ac_device)
    if target is None:
        message = "未启用连接方式"
        fact_repository.update_collect_run_status(collect_run_uuid, "failed", error_message=message)
        app_logger.log_error("AC_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        _write_raw_files(raw_log_file, commands_file, ac_device, collect_run_uuid, command_results, fatal_error=message)
        return AcResourceCollectResult(False, str(ac_device.device_uuid), collect_run_uuid, str(raw_log_file), False, 0, None, False, False, None, message, command_results)

    connection = None
    try:
        command_guard.validate_command_list(["screen-length disable", *RESOURCE_COMMANDS, *HTTPS_PORT_COMMANDS], "ac_collect")
        connection = netmiko_connection.ConnectHandler(**build_netmiko_params(target))
        command_results.append(_run_command(connection, "screen-length disable", ac_device, collect_run_uuid, context="ac_collect"))
        outputs: dict[str, str] = {}
        for command in RESOURCE_COMMANDS:
            result = _run_command(connection, command, ac_device, collect_run_uuid, context="ac_collect")
            command_results.append(result)
            if result.success:
                outputs[command] = result.output
        https_port, https_results = collect_https_port(connection, ac_device, collect_run_uuid)
        command_results.extend(https_results)
        _write_raw_files(raw_log_file, commands_file, ac_device, collect_run_uuid, command_results)
        summary, resources = parse_ac_resource_outputs(outputs, str(ac_device.device_uuid), collect_run_uuid, relative_raw_log_path)
        summary_updated = any(value is not None for key, value in summary.items() if key != "ac_device_uuid")
        if summary_updated:
            repository.upsert_ac_ap_summary(summary)
        persistence = _update_https_port(repository.database, ac_device, collect_run_uuid, https_port)
        repository.replace_fit_ap_resources(str(ac_device.device_uuid), resources)
        status = "success" if summary_updated or resources else "failed"
        error_message = _command_error_summary(command_results)
        fact_repository.update_collect_run_status(collect_run_uuid, status, error_message=error_message or None)
        if status == "success":
            app_logger.log_info("FIT_AP_RESOURCE_UPDATED", _detail(ac_device, collect_run_uuid, count=len(resources)))
            app_logger.log_info("AC_COLLECT_SUCCESS", _detail(ac_device, collect_run_uuid))
            app_logger.log_info("REAL_DEVICE_COLLECT_SUCCESS", _detail(ac_device, collect_run_uuid))
        else:
            app_logger.log_error("AC_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=error_message or "no data parsed"))
            app_logger.log_error("REAL_DEVICE_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=error_message or "no data parsed"))
        return AcResourceCollectResult(
            status == "success",
            str(ac_device.device_uuid),
            collect_run_uuid,
            str(raw_log_file),
            summary_updated,
            len(resources),
            https_port,
            https_port is not None,
            persistence.persisted,
            persistence.error_message,
            error_message or None,
            command_results,
        )
    except Exception as exc:
        message = sanitize_sensitive_text(str(exc), ac_device)
        _write_raw_files(raw_log_file, commands_file, ac_device, collect_run_uuid, command_results, fatal_error=message)
        fact_repository.update_collect_run_status(collect_run_uuid, "failed", error_message=message)
        app_logger.log_error("AC_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        app_logger.log_error("REAL_DEVICE_COLLECT_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        return AcResourceCollectResult(False, str(ac_device.device_uuid), collect_run_uuid, str(raw_log_file), False, 0, None, False, False, None, message, command_results)
    finally:
        if connection is not None:
            _disconnect(connection)


def collect_h3c_fit_ap_optical(
    ac_device: Device,
    site_name: str,
    repository: AcRepository | None = None,
    paths: PathResolver | None = None,
    max_workers: int = BATCH_CONCURRENCY,
) -> FitApOpticalCollectResult:
    paths = paths or PathResolver()
    repository = repository or AcRepository(Database(paths.site_db_path(site_name)))
    fact_repository = DeviceFactRepository(repository.database)
    ac_device.ensure_device_uuid()
    collect_run_uuid = str(uuid4())
    started_at = _now()
    run_dir = paths.ensure_site_dirs(site_name) / "raw" / "ac" / collect_run_uuid
    fit_ap_dir = run_dir / "fit_ap"
    fit_ap_dir.mkdir(parents=True, exist_ok=True)
    fact_repository.create_collect_run(
        {
            "collect_run_uuid": collect_run_uuid,
            "collect_type": "fit_ap_optical",
            "status": "running",
            "started_at": started_at,
            "raw_log_dir": f"raw/ac/{collect_run_uuid}",
            "created_at": started_at,
        }
    )
    app_logger.log_info("FIT_AP_OPTICAL_STARTED", _detail(ac_device, collect_run_uuid))
    try:
        app_logger.log_info("FIT_AP_OPTICAL_AC_ENABLE_STARTED", _detail(ac_device, collect_run_uuid))
        enable_results = _enable_fit_ap_console(ac_device, collect_run_uuid)
        _write_raw_files(run_dir / f"{ac_device.device_uuid}.log", run_dir / f"{ac_device.device_uuid}_commands.jsonl", ac_device, collect_run_uuid, enable_results)
        if any(not result.success for result in enable_results):
            raise RuntimeError(_command_error_summary(enable_results) or "AC enable AP console failed")
        app_logger.log_info("FIT_AP_OPTICAL_AC_ENABLE_SUCCESS", _detail(ac_device, collect_run_uuid))
    except Exception as exc:
        message = sanitize_sensitive_text(str(exc), ac_device)
        app_logger.log_error("FIT_AP_OPTICAL_AC_ENABLE_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        app_logger.log_error("FIT_AP_OPTICAL_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        fact_repository.update_collect_run_status(collect_run_uuid, "failed", error_message=message)
        return FitApOpticalCollectResult(False, False, str(ac_device.device_uuid), collect_run_uuid, 0, 0, message)

    resources = [row for row in repository.list_fit_ap_resources_with_metadata(str(ac_device.device_uuid)) if row.get("ap_ip")]
    rows: list[dict[str, object | None]] = []
    worker_count = max(1, min(int(max_workers or BATCH_CONCURRENCY), 1000))
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(_collect_single_fit_ap_optical, ac_device, row, site_name, collect_run_uuid, fit_ap_dir, paths): row
            for row in resources
        }
        for future in as_completed(futures):
            rows.append(future.result())
    repository.replace_fit_ap_optical(str(ac_device.device_uuid), rows)
    app_logger.log_info("FIT_AP_OPTICAL_DB_SAVED", _detail(ac_device, collect_run_uuid, count=len(rows)))
    failed = sum(1 for row in rows if row.get("status") != "success")
    status = "failed" if rows and failed == len(rows) else "partial_success" if failed else "success"
    if not rows:
        status = "failed"
    error_message = f"failed_aps={failed}" if failed else None
    fact_repository.update_collect_run_status(collect_run_uuid, status, error_message=error_message)
    if status == "success":
        app_logger.log_info("FIT_AP_OPTICAL_SUCCESS", _detail(ac_device, collect_run_uuid, count=len(rows)))
    elif status == "partial_success":
        app_logger.log_warning("FIT_AP_OPTICAL_PARTIAL_SUCCESS", _detail(ac_device, collect_run_uuid, count=len(rows), error=error_message or ""))
    else:
        app_logger.log_error("FIT_AP_OPTICAL_FAILED", _detail(ac_device, collect_run_uuid, error=error_message or "no AP resources"))
    return FitApOpticalCollectResult(status != "failed", status == "partial_success", str(ac_device.device_uuid), collect_run_uuid, len(rows), failed, error_message)


def parse_ac_resource_outputs(
    outputs: dict[str, str],
    ac_device_uuid: str,
    collect_run_uuid: str,
    raw_log_path: str,
) -> tuple[dict[str, object | None], list[dict[str, object | None]]]:
    collected_at = _now()
    metadata = {"collected_at": collected_at, "updated_at": collected_at, "collect_run_uuid": collect_run_uuid, "raw_log_path": raw_log_path}
    ap_all = outputs.get("display wlan ap all", "")
    device_facts = parse_device(
        outputs.get("display version", ""),
        outputs.get("display device", ""),
        outputs.get("display device manuinfo", ""),
    )
    summary = {
        "ac_device_uuid": ac_device_uuid,
        **parse_wlan_ap_summary(ap_all),
        **parse_cpu_usage(outputs.get("display cpu-usage", "")),
        **parse_memory(outputs.get("display memory", "")),
        "model": device_facts.get("model"),
        "serial_number": device_facts.get("serial_number"),
        "software_version": device_facts.get("software_version"),
        **metadata,
    }
    ap_rows = parse_wlan_ap_list(ap_all)
    address_rows = parse_wlan_ap_addresses(outputs.get("display wlan ap all address", ""))
    radio_rows = parse_wlan_ap_radios(outputs.get("display wlan ap all radio", ""))
    resources: list[dict[str, object | None]] = []
    for row in ap_rows:
        ap_name = str(row.get("ap_name") or "")
        resources.append(
            {
                "ac_device_uuid": ac_device_uuid,
                **row,
                **address_rows.get(ap_name, {}),
                **radio_rows.get(ap_name, {}),
                **metadata,
            }
        )
    return summary, resources


def collect_https_port(connection, ac_device: Device, collect_run_uuid: str) -> tuple[int | None, list[CommandResult]]:
    app_logger.log_info("AC_HTTPS_PORT_COMMAND_STARTED", _detail(ac_device, collect_run_uuid, error="command_executed=true"))
    results: list[CommandResult] = []
    for command in HTTPS_PORT_COMMANDS:
        result = _run_command(connection, command, ac_device, collect_run_uuid, context="ac_collect")
        results.append(result)
        output_length = len(result.output or "")
        app_logger.log_info("AC_HTTPS_PORT_COMMAND_RESULT", _detail(ac_device, collect_run_uuid, command=command, error=f"output_length={output_length}"))
        if not result.success:
            continue
        for line in matching_https_port_lines(result.output):
            app_logger.log_info("AC_HTTPS_PORT_MATCHED_LINE", _detail(ac_device, collect_run_uuid, error=f'matched_line="{line}"'))
        port = parse_https_port(result.output)
        app_logger.log_info("AC_HTTPS_PORT_PARSED", _detail(ac_device, collect_run_uuid, command=command, error=f"parsed_port={port if port is not None else 'none'}"))
        if port is not None:
            return port, results
    return None, results


def _update_https_port(database: Database, ac_device: Device, collect_run_uuid: str, port: int | None) -> HttpsPortPersistenceResult:
    if port is None:
        app_logger.log_info("AC_HTTPS_PORT_NOT_COLLECTED", _detail(ac_device, collect_run_uuid, error="no valid HTTPS port parsed"))
        return HttpsPortPersistenceResult(None, False)
    if ac_device.id is None:
        message = f"device_id_missing, parsed_port={port}"
        app_logger.log_info("AC_HTTPS_PORT_NOT_SAVED", _detail(ac_device, collect_run_uuid, error=message))
        return HttpsPortPersistenceResult(None, False, message)
    try:
        repository = DeviceRepository(database)
        old_port = repository.get(int(ac_device.id)).https_port
        app_logger.log_info("AC_HTTPS_PORT_DB_BEFORE", _detail(ac_device, collect_run_uuid, error=f"old_db_port={old_port}"))
        repository.update_https_port(int(ac_device.id), port)
        saved_device = repository.get(int(ac_device.id))
        if saved_device.https_port != port:
            message = f"persistence verification failed, parsed_port={port}, persisted_port={saved_device.https_port}"
            app_logger.log_warning("AC_HTTPS_PORT_SAVE_FAILED", _detail(ac_device, collect_run_uuid, error=message))
            return HttpsPortPersistenceResult(saved_device.https_port, False, message)
        ac_device.https_port = saved_device.https_port
        app_logger.log_info(
            "AC_HTTPS_PORT_UPDATED",
            _detail(ac_device, collect_run_uuid, error=f"parsed_port={port}, persisted_port={saved_device.https_port}, persistence_verified=true"),
        )
        return HttpsPortPersistenceResult(saved_device.https_port, True)
    except Exception as exc:
        message = sanitize_sensitive_text(str(exc), ac_device)
        app_logger.log_warning("AC_HTTPS_PORT_SAVE_FAILED", _detail(ac_device, collect_run_uuid, error=message))
        return HttpsPortPersistenceResult(None, False, message)


def _enable_fit_ap_console(ac_device: Device, collect_run_uuid: str) -> list[CommandResult]:
    target = choose_connection_target(ac_device)
    if target is None:
        raise RuntimeError("未启用连接方式")
    connection = None
    results: list[CommandResult] = []
    try:
        command_guard.validate_command_list(ENABLE_FIT_AP_CONSOLE_COMMANDS, "ac_enable_ap_console")
        connection = netmiko_connection.ConnectHandler(**build_netmiko_params(target))
        for command in ENABLE_FIT_AP_CONSOLE_COMMANDS:
            results.append(_run_command(connection, command, ac_device, collect_run_uuid, read_timeout=10, context="ac_enable_ap_console"))
        return results
    finally:
        if connection is not None:
            _disconnect(connection)


def _collect_single_fit_ap_optical(
    ac_device: Device,
    ap_row: dict[str, object | None],
    site_name: str,
    collect_run_uuid: str,
    fit_ap_dir: Path,
    paths: PathResolver,
) -> dict[str, object | None]:
    ap_name = str(ap_row.get("ap_name") or ap_row.get("ap_ip") or "fit_ap")
    ap_ip = str(ap_row.get("ap_ip") or "")
    raw_log_file = fit_ap_dir / f"{_safe_filename(ap_name)}.log"
    commands_file = fit_ap_dir / f"{_safe_filename(ap_name)}_commands.jsonl"
    relative_raw_log_path = f"raw/ac/{collect_run_uuid}/fit_ap/{_safe_filename(ap_name)}.log"
    collected_at = _now()
    base = {
        "ac_device_uuid": ac_device.device_uuid,
        "ap_uuid": ap_row.get("ap_uuid"),
        "ap_name": ap_name,
        "ap_mac": ap_row.get("ap_mac"),
        "ap_ip": ap_ip,
        "site": ap_row.get("site"),
        "collected_at": collected_at,
        "updated_at": collected_at,
        "collect_run_uuid": collect_run_uuid,
        "raw_log_path": relative_raw_log_path,
    }
    temp_device = Device(
        name=ap_name,
        device_uuid=ac_device.device_uuid,
        ip_address=ap_ip,
        ssh_enabled=0,
        telnet_enabled=1,
        telnet_port=23,
        telnet_username="",
        telnet_password="h3capadmin",
    )
    command_results: list[CommandResult] = []
    connection = None
    app_logger.log_info("FIT_AP_OPTICAL_AP_STARTED", _detail(ac_device, collect_run_uuid, ap=ap_name))
    try:
        target = choose_connection_target(temp_device)
        if target is None:
            raise RuntimeError("AP Telnet target unavailable")
        connection = netmiko_connection.ConnectHandler(**build_netmiko_params(target))
        command_guard.validate_command_list(FIT_AP_OPTICAL_COMMANDS, "fit_ap_collect")
        outputs: dict[str, str] = {}
        for command in FIT_AP_OPTICAL_COMMANDS:
            result = _run_command(connection, command, temp_device, collect_run_uuid, read_timeout=15, context="fit_ap_collect")
            command_results.append(result)
            if result.success:
                outputs[command] = result.output
        _write_raw_files(raw_log_file, commands_file, temp_device, collect_run_uuid, command_results)
        parsed = parse_fit_ap_optical(
            outputs.get("display lldp neighbor-information list", ""),
            outputs.get("display transceiver diagnosis interface", ""),
            outputs.get("display transceiver interface", ""),
            outputs.get("display transceiver manuinfo interface", ""),
        )
        if _is_invalid_lldp_neighbor(parsed.get("lldp_neighbor")):
            parsed["lldp_neighbor"] = None
            parsed["neighbor_device_name"] = None
        reverse_match = match_ap_from_device_lldp(site_name, ap_mac=str(ap_row.get("ap_mac") or ""), ap_name=ap_name, paths=paths)
        match = reverse_match if reverse_match.device_uuid else match_neighbor_device(
            site_name,
            neighbor_mac=str(parsed.get("neighbor_mac") or ""),
            neighbor_sysname=str(parsed.get("lldp_neighbor") or ""),
            neighbor_interface=str(parsed.get("neighbor_interface") or ""),
            paths=paths,
        )
        if match.device_uuid:
            app_logger.log_info("FIT_AP_OPTICAL_NEIGHBOR_MATCHED", _detail(ac_device, collect_run_uuid, ap=ap_name, error=f"matched_by={match.matched_by}"))
        else:
            app_logger.log_warning("FIT_AP_OPTICAL_NEIGHBOR_MATCH_FAILED", _detail(ac_device, collect_run_uuid, ap=ap_name))
        if match.station:
            base["site"] = match.station
        if match.matched_by == "device_lldp":
            parsed["neighbor_device_name"] = match.device_name
            parsed["neighbor_interface"] = match.local_interface
            parsed["interface_name"] = match.ap_interface or parsed.get("interface_name")
        else:
            parsed["neighbor_device_name"] = match.device_name or parsed.get("lldp_neighbor")
        if _is_invalid_lldp_neighbor(parsed.get("neighbor_device_name")):
            parsed["neighbor_device_name"] = None
        neighbor_optical = find_neighbor_optical_module(site_name, match.device_uuid, str(parsed.get("neighbor_interface") or ""), paths=paths)
        parsed["neighbor_rx_power"] = str(neighbor_optical.get("rx_power")) if neighbor_optical and neighbor_optical.get("rx_power") else None
        # optical_alarm_status is no longer stored — computed real-time by optical_severity_engine
        success = any(parsed.values()) and all(result.success for result in command_results)
        status = "success" if success else "failed"
        app_logger.log_info("FIT_AP_OPTICAL_AP_SUCCESS" if success else "FIT_AP_OPTICAL_AP_FAILED", _detail(ac_device, collect_run_uuid, ap=ap_name, error="" if success else _command_error_summary(command_results) or "no optical data parsed"))
        return {**base, **parsed, "status": status, "error_message": None if success else _command_error_summary(command_results) or "no optical data parsed"}
    except Exception as exc:
        message = sanitize_sensitive_text(str(exc), temp_device)
        _write_raw_files(raw_log_file, commands_file, temp_device, collect_run_uuid, command_results, fatal_error=message)
        app_logger.log_error("FIT_AP_OPTICAL_AP_FAILED", _detail(ac_device, collect_run_uuid, ap=ap_name, error=message))
        return {
            **base,
            "lldp_neighbor": None,
            "neighbor_interface": None,
            "neighbor_mac": None,
            "neighbor_device_name": None,
            "neighbor_rx_power": None,
            "interface_name": None,
            "temperature": None,
            "tx_power": None,
            "rx_power": None,
            "status": "failed",
            "error_message": message,
        }
    finally:
        if connection is not None:
            _disconnect(connection)


def _run_command(connection, command: str, device: Device, collect_run_uuid: str, read_timeout: int = 30, context: str = "ac_collect") -> CommandResult:
    reason = command_guard.command_reject_reason(command, context)
    if reason:
        command_guard.log_command_rejected(command, context, reason)
        return CommandResult(command=command, success=False, error_message=reason)
    app_logger.log_info("COMMAND_ALLOWED", _detail(device, collect_run_uuid, command=command))
    try:
        output = netmiko_connection.safe_send_command(
            connection,
            command,
            read_timeout=read_timeout,
            use_timing=True,
            encoding=netmiko_connection.encoding_for_vendor(device.device_vendor),
        )
    except Exception as exc:
        message = sanitize_sensitive_text(str(exc), device)
        return CommandResult(command=command, success=False, error_message=message)
    return CommandResult(command=command, success=True, output=str(output or ""))


def _write_raw_files(
    raw_log_file: Path,
    commands_file: Path,
    device: Device,
    collect_run_uuid: str,
    command_results: list[CommandResult],
    fatal_error: str | None = None,
) -> None:
    raw_log_file.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"Collect Time: {_now()}",
        f"Collect Run UUID: {collect_run_uuid}",
        f"Device Name: {device.name}",
        f"Device IP: {device.ip_address}",
        "",
    ]
    for result in command_results:
        lines.extend(
            [
                f"===== COMMAND: {result.command} =====",
                f"Success: {result.success}",
                f"Error: {result.error_message or ''}",
                result.output or "",
                "",
            ]
        )
    if fatal_error:
        lines.extend(["===== FATAL ERROR =====", fatal_error, ""])
    raw_log_file.write_text("\n".join(lines), encoding="utf-8")
    with commands_file.open("w", encoding="utf-8") as file:
        for result in command_results:
            file.write(json.dumps({"command": result.command, "success": result.success, "error_message": result.error_message}, ensure_ascii=False) + "\n")


def _command_error_summary(command_results: list[CommandResult]) -> str:
    return "; ".join(f"{item.command}: {item.error_message}" for item in command_results if not item.success)


def _disconnect(connection) -> None:
    try:
        connection.disconnect()
    except Exception:
        pass


def _detail(device: Device, collect_run_uuid: str, command: str = "", error: str = "", count: int | None = None, ap: str = "") -> str:
    parts = [f"device={device.name}", f"ip={device.ip_address}", f"collect_run_uuid={collect_run_uuid}"]
    if ap:
        parts.append(f"ap={ap}")
    if command:
        parts.append(f"command={command}")
    if count is not None:
        parts.append(f"count={count}")
    if error:
        parts.append(f"error={error}")
    return ", ".join(parts)


def _safe_filename(value: str) -> str:
    return "".join(char if char.isalnum() or char in "-_." else "_" for char in value)[:120] or "fit_ap"


def _evaluate_neighbor_optical_status(rx_power: object, neighbor_optical: dict[str, object | None] | None) -> str:
    from netconsole.core.optical_severity_engine import compute_optical_severity

    if neighbor_optical:
        return compute_optical_severity(
            {
                "switch_rx_power": neighbor_optical.get("rx_power"),
                "switch_port_status": neighbor_optical.get("port_status"),
                "alarm_low": neighbor_optical.get("rx_low_alarm"),
                "alarm_high": neighbor_optical.get("rx_high_alarm"),
                "warning_low": neighbor_optical.get("rx_low_warning"),
            }
        ).severity
    return compute_optical_severity({"switch_rx_power": rx_power}).severity


def _worse_optical_status(left: str, right: str) -> str:
    from netconsole.core.optical_severity_engine import worse_optical_severity

    return worse_optical_severity(left, right)


def _to_float(value: object) -> float | None:
    import re

    match = re.search(r"[-+]?\d+(?:\.\d+)?", str(value or ""))
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _is_invalid_lldp_neighbor(value: object) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    lowered = text.casefold()
    return any(token.casefold() in lowered for token in ("Nearest", "Chassis ID", "Default", "customer bridge", "nontpmr"))


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")
